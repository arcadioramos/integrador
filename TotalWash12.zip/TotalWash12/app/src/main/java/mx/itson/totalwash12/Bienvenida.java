package mx.itson.totalwash12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Bienvenida extends AppCompatActivity {

    //Se crean los objetos para los controles que vamos a usar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenida);

        //Se crea la relación para la comunicación de la parte lógica con la parte gráfica de la aplicación

        //se le asiga la imagen de google al botón
        ((Button) findViewById(R.id.gbtn)).setBackgroundResource(R.drawable.g_icon);
    }

    //Método para el botón de registrar
    public void  Registrate (View view){

        Intent i = new Intent(this, registroUsuario.class);
        startActivity(i);
    }

}
