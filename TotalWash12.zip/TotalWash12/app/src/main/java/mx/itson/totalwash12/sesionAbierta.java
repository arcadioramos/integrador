package mx.itson.totalwash12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class sesionAbierta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sesion_abierta);
    }
}
