package mx.itson.totalwash12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //se crea y se compara si el usuario esta logueado para decidir en cual ventana inicia la app

        boolean logueado = false;

        if (logueado == false){
            EnviarBienvenida();
        }else{
            EnviarRegistro();
        }


    }

    //metodo que envia a la pantalla para loguearse/registrarse
    public void EnviarBienvenida (){

        Intent i = new Intent(this, Bienvenida.class);
        startActivity(i);
    }

    //metodo que envia a la pantalla para Registro
    public void EnviarRegistro (){

        Intent i = new Intent(this, registroUsuario.class);
        startActivity(i);
    }
}
