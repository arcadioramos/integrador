/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author PAVILION
 */
public class Conexion {
    private static Connection conexion;
    public static String db = "jnorza.ga";
    private static String driver = "com.mysql.jdbc.Driver";
    public static String stringConexion = "jdbc:mysql://jnorza.ga:3306/integrador";
    public static String password = "R1v3ra@2020";
    public static String usuario = "jesusrv";
                public static Connection getConnection() {
        try {
            Class.forName(driver);
            try {
                conexion = DriverManager.getConnection(stringConexion, usuario, password);
            } catch (SQLException ex) {
                System.out.println("Ocurrió un error al conectar: " + ex.getMessage()); 
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Ocurrió un error: " + ex.getMessage()); 
        }
        return conexion
                ;
                    
    }
    
}