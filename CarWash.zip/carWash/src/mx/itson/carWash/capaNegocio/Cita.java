/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaNegocio;

import java.util.Date;

/**
 *
 * @author PAVILION
 */
public class Cita {

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the id
     */ 
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

 

    /**
     * @return the aprobacion
     */
    public int getAprobacion() {
        return aprobacion;
    }

    /**
     * @param aprobacion the aprobacion to set
     */
    public void setAprobacion(int aprobacion) {
        this.aprobacion = aprobacion;
    }
    private int id;
    private int idCliente;
    private String fecha;
    private int aprobacion; 
}
