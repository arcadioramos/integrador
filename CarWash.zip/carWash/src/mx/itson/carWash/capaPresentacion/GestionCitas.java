/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPresentacion;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mx.itson.carWash.capaNegocio.Cita;
import mx.itson.carWash.capaPersistencia.GestionarCitasImpl;

/**
 *
 * @author PAVILION
 */
public class GestionCitas extends javax.swing.JFrame {

    DefaultTableModel modelo;
    DefaultTableModel modelo2;
    static int x;
    static GestionarCitasImpl ec = new GestionarCitasImpl();
   
    /**
     * Creates new form GestionCitas
     */
    public GestionCitas() {
        initComponents();
        
        modelo = (DefaultTableModel) TablaCitasNoAprobadas.getModel();
        modelo2 = (DefaultTableModel) TablaCitasAprobadas.getModel();
        rellenarTablaNoAprobado();
        rellenarTablaAprobado();
    }
        
    public void rellenarTablaNoAprobado() {   
        
        java.util.List<Cita> listaCitas = new ArrayList();
        listaCitas = (ArrayList) ec.MostrarCitasNoAprobadas();
        //Se crea esta condición para que no duplique valores
         modelo.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int x = listaCitas.get(i).getId();
                int y = listaCitas.get(i).getIdCliente();
                String z = listaCitas.get(i).getFecha();
                int a = listaCitas.get(i).getAprobacion();  
                
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //Se añade la fila a la tabla
                modelo.addRow(v);

            }
        
        
    }
    public void rellenarTablaAprobado() {   
        
        java.util.List<Cita> listaCitasAprobadas = new ArrayList();
        listaCitasAprobadas = (ArrayList) ec.MostrarCitasAprobadas();
        //Se crea esta condición para que no duplique valores
         modelo2.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasAprobadas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int x = listaCitasAprobadas.get(i).getId();
                int y = listaCitasAprobadas.get(i).getIdCliente();
                String z = listaCitasAprobadas.get(i).getFecha();
                int a = listaCitasAprobadas.get(i).getAprobacion();  
                
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //Se añade la fila a la tabla
                modelo2.addRow(v);

            }
        
        
    }
    public void rellenarTablaCitaNoAprobadaPorFecha(String fechaInicial, String fechaFinal) {
        GestionarCitasImpl gc = new GestionarCitasImpl();
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        
        listaCitasFiltradas = (ArrayList) gc.mostrarCitasNoAprobadasPorFecha(fechaInicial, fechaFinal);
            //Se crea esta condición para que no duplique valores
            modelo.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasFiltradas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaCitasFiltradas.get(i).getId();
                int b = listaCitasFiltradas.get(i).getIdCliente();
                String c = listaCitasFiltradas.get(i).getFecha();
                int d = listaCitasFiltradas.get(i).getAprobacion();
                v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                
                //Se añade la fila a la tabla
                modelo.addRow(v);
            
            
        }
            

    }
    public void rellenarTablaCitaAprobadaPorFecha(String fechaInicial, String fechaFinal) {
        GestionarCitasImpl gc = new GestionarCitasImpl();
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        
        listaCitasFiltradas = (ArrayList) gc.mostrarCitasAprobadasPorFecha(fechaInicial, fechaFinal);
            //Se crea esta condición para que no duplique valores
            modelo2.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasFiltradas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaCitasFiltradas.get(i).getId();
                int b = listaCitasFiltradas.get(i).getIdCliente();
                String c = listaCitasFiltradas.get(i).getFecha();
                int d = listaCitasFiltradas.get(i).getAprobacion();
                v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                
                //Se añade la fila a la tabla
                modelo2.addRow(v);
            
            
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCitasAprobadas = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TablaCitasNoAprobadas = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        botonAceptarCita = new javax.swing.JButton();
        fechaInicio = new com.toedter.calendar.JDateChooser();
        fechaFin = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        lblLogo = new javax.swing.JLabel();
        lblFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(74, 189, 172));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("GESTOR DE CITAS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(269, 19, 322, -1));

        TablaCitasAprobadas.setBackground(new java.awt.Color(0, 0, 51));
        TablaCitasAprobadas.setForeground(new java.awt.Color(255, 255, 255));
        TablaCitasAprobadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id", "idCliente", "Fecha cita", "Aprobación"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.Long.class, java.lang.String.class, java.lang.Byte.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaCitasAprobadas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 327, 174));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("No aprobadas");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, -1, -1));

        TablaCitasNoAprobadas.setBackground(new java.awt.Color(0, 0, 51));
        TablaCitasNoAprobadas.setForeground(new java.awt.Color(255, 255, 255));
        TablaCitasNoAprobadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id", "idCliente", "Fecha cita", "Aprobación"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.Long.class, java.lang.String.class, java.lang.Byte.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaCitasNoAprobadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaCitasNoAprobadasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TablaCitasNoAprobadas);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(533, 327, 327, 174));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Aprobadas");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 281, -1, -1));

        botonAceptarCita.setBackground(new java.awt.Color(0, 0, 51));
        botonAceptarCita.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        botonAceptarCita.setForeground(new java.awt.Color(255, 255, 255));
        botonAceptarCita.setText("Aceptar cita");
        botonAceptarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCitaActionPerformed(evt);
            }
        });
        jPanel1.add(botonAceptarCita, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 270, -1, -1));

        fechaInicio.setBackground(new java.awt.Color(0, 0, 51));
        fechaInicio.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(fechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(482, 174, 130, -1));

        fechaFin.setBackground(new java.awt.Color(0, 0, 51));
        fechaFin.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(fechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(645, 174, 130, -1));

        jButton1.setBackground(new java.awt.Color(0, 0, 51));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Filtrar Fecha");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 220, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Fecha inicio");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(482, 152, -1, -1));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Fecha fin");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(645, 152, -1, -1));

        jButton2.setBackground(new java.awt.Color(0, 0, 51));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Regresar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(749, 44, -1, -1));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mx/itson/carWash/capaPresentacion/imagenes/logoTWPeque.png"))); // NOI18N
        jPanel1.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        lblFondo.setForeground(new java.awt.Color(255, 255, 255));
        lblFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mx/itson/carWash/capaPresentacion/imagenes/FondoPrograma.jpg"))); // NOI18N
        lblFondo.setText("jLabel6");
        jPanel1.add(lblFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 570));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonAceptarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCitaActionPerformed

        ec.aceptarCita(x);
        rellenarTablaNoAprobado();
        rellenarTablaAprobado();
    }//GEN-LAST:event_botonAceptarCitaActionPerformed

    private void TablaCitasNoAprobadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaCitasNoAprobadasMouseClicked
       //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = TablaCitasNoAprobadas.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) TablaCitasNoAprobadas.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        x =(Integer) modelotabla.getValueAt(filaSeleccionada, 0);
        
        
        
        
    }//GEN-LAST:event_TablaCitasNoAprobadasMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try {
            Date fecha1 = fechaInicio.getDate();
            DateFormat f1 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaInicial = f1.format(fecha1);

            Date fecha2 = fechaFin.getDate();
            DateFormat f2 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaFinal = f2.format(fecha2);

            rellenarTablaCitaNoAprobadaPorFecha(fechaInicial, fechaFinal);
            rellenarTablaCitaAprobadaPorFecha(fechaInicial, fechaFinal);
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Ingresar datos en fechas");
        }    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionCitas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaCitasAprobadas;
    private javax.swing.JTable TablaCitasNoAprobadas;
    private javax.swing.JButton botonAceptarCita;
    private com.toedter.calendar.JDateChooser fechaFin;
    private com.toedter.calendar.JDateChooser fechaInicio;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblFondo;
    private javax.swing.JLabel lblLogo;
    // End of variables declaration//GEN-END:variables
}
