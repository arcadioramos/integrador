/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPresentacion;

import com.toedter.calendar.JCalendar;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mx.itson.carWash.capaNegocio.Producto;
import mx.itson.carWash.capaNegocio.Servicio;
import mx.itson.carWash.capaNegocio.Session;
import mx.itson.carWash.capaNegocio.Usuario;
import mx.itson.carWash.capaPersistencia.AgregarProductoImpl;
import mx.itson.carWash.capaPersistencia.AgregarServicioImpl;
import mx.itson.carWash.capaPersistencia.CerrarSesionImpl;
import mx.itson.carWash.capaPersistencia.EditarClienteImpl;
import mx.itson.carWash.capaPersistencia.IniciarSesionImpl;

/**
 *
 * @author HP Pavilion
 */
public class AgregarServicio extends javax.swing.JFrame {

    private static VentanaPrincipal vp = new VentanaPrincipal();
    DefaultTableModel modelo;
    DefaultTableModel modelo2;
    DefaultTableModel modelo3;

    /**
     * Creates new form AgregarServicio
     */
    public AgregarServicio() {
        initComponents();
        modelo = (DefaultTableModel) tablaClientes.getModel();
        modelo2 = (DefaultTableModel) tablaEmpleados.getModel();
        modelo3 = (DefaultTableModel) tablaProductos.getModel();
        rellenarTablaCliente();
        rellenarTablaEmpleado();
        rellenarTablaProductos();
        try {
            IniciarSesionImpl i = new IniciarSesionImpl();
            Session s = (Session) i.Session();
            label.setText("Bienvenido: " + s.getNombre() + " " + s.getApellidos());
            Blob blob = s.getImagen();
            byte[] data = blob.getBytes(1, (int) blob.length());
            BufferedImage img = null;
            try {
                img = ImageIO.read(new ByteArrayInputStream(data));
            } catch (Exception ex) {
                System.out.println(ex);
            }
            ImageIcon image = new ImageIcon(img);
            ImageIcon icono = new ImageIcon(image.getImage().getScaledInstance(imagenLbl.getWidth(), imagenLbl.getHeight(), Image.SCALE_DEFAULT));
            imagenLbl.setIcon(icono);
            modelo = (DefaultTableModel) tablaClientes.getModel();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        //rellenarTabla(busqueda);
    }

    public void rellenarTablaCliente() {
        AgregarServicioImpl asi = new AgregarServicioImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) asi.MostrarClientes();
        //Se crea esta condición para que no duplique valores
        modelo.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        for (int i = 0; i < listaUsuarios.size(); i++) {
            //Se crea un vector para poder añadir filas
            Vector v = new Vector();
            //Cada variable representa una columna en la fila del vector
            int a = listaUsuarios.get(i).getId();
            String b = listaUsuarios.get(i).getNombre();
            String c = listaUsuarios.get(i).getApellidos();
            String d = listaUsuarios.get(i).getCorreo();
            int e = listaUsuarios.get(i).getTipoUsuario();
            //v.add(a);
            v.add(b); //Get del nombre
            v.add(c); //Get de apellidos
            v.add(d); //Get de correo
            // v.add(e);
            //Se añade la fila a la tabla
            modelo.addRow(v);

        }

    }

    public void rellenarTablaEmpleado() {
        AgregarServicioImpl asi = new AgregarServicioImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) asi.MostrarEmpleados();
        //Se crea esta condición para que no duplique valores
        modelo2.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        for (int i = 0; i < listaUsuarios.size(); i++) {
            //Se crea un vector para poder añadir filas
            Vector v = new Vector();
            //Cada variable representa una columna en la fila del vector
            int a = listaUsuarios.get(i).getId();
            String b = listaUsuarios.get(i).getNombre();
            String c = listaUsuarios.get(i).getApellidos();
            String d = listaUsuarios.get(i).getCorreo();
            int e = listaUsuarios.get(i).getTipoUsuario();
            //v.add(a);
            v.add(b); //Get del nombre
            v.add(c); //Get de apellidos
            v.add(d); //Get de correo
            // v.add(e);
            //Se añade la fila a la tabla
            modelo2.addRow(v);

        }

    }

    public void rellenarTablaBusquedaCliente(String nombre) {
        AgregarServicioImpl asi = new AgregarServicioImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) asi.MostrarClientesBusqueda(nombre);
        //Se crea esta condición para que no duplique valores
        modelo.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        for (int i = 0; i < listaUsuarios.size(); i++) {
            //Se crea un vector para poder añadir filas
            Vector v = new Vector();
            //Cada variable representa una columna en la fila del vector
            int a = listaUsuarios.get(i).getId();
            String b = listaUsuarios.get(i).getNombre();
            String c = listaUsuarios.get(i).getApellidos();
            String d = listaUsuarios.get(i).getCorreo();
            int e = listaUsuarios.get(i).getTipoUsuario();
            //v.add(a);
            v.add(b); //Get del nombre
            v.add(c); //Get de apellidos
            v.add(d); //Get de correo
            // v.add(e);
            //Se añade la fila a la tabla
            modelo.addRow(v);

        }

    }

    public void rellenarTablaBusquedaEmpleado(String nombre) {
        AgregarServicioImpl asi = new AgregarServicioImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) asi.MostrarEmpleadosBusqueda(nombre);
        //Se crea esta condición para que no duplique valores
        modelo2.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        for (int i = 0; i < listaUsuarios.size(); i++) {
            //Se crea un vector para poder añadir filas
            Vector v = new Vector();
            //Cada variable representa una columna en la fila del vector
            int a = listaUsuarios.get(i).getId();
            String b = listaUsuarios.get(i).getNombre();
            String c = listaUsuarios.get(i).getApellidos();
            String d = listaUsuarios.get(i).getCorreo();
            int e = listaUsuarios.get(i).getTipoUsuario();
            //v.add(a);
            v.add(b); //Get del nombre
            v.add(c); //Get de apellidos
            v.add(d); //Get de correo
            // v.add(e);
            //Se añade la fila a la tabla
            modelo2.addRow(v);

        }

    }

    public void rellenarTablaProductos() {
        AgregarProductoImpl ap = new AgregarProductoImpl();
        java.util.List<Producto> listaProductos = new ArrayList();
        listaProductos = (ArrayList) ap.mostrarProductos();
        //Se crea esta condición para que no duplique valores
        modelo3.setRowCount(0);

        //Se crea un for para recorrer el array con los productos
        for (int i = 0; i < listaProductos.size(); i++) {
            //Se crea un vector para poder añadir filas
            Vector v = new Vector();
            //Cada variable representa una columna en la fila del vector
            String x = listaProductos.get(i).getNombre();
            double y = listaProductos.get(i).getCosto();
            String z = listaProductos.get(i).getDescripcion();
            String a = listaProductos.get(i).getCodigo();
            int b = listaProductos.get(i).getId();
            v.add(x);
            v.add(y);
            v.add(z);
            v.add(a);
            //  v.add(b);
            //Se añade la fila a la tabla
            modelo3.addRow(v);

        }

    }

    public void realizarCompra() {
        AgregarServicioImpl asi = new AgregarServicioImpl();
        Usuario usuarioCliente = new Usuario();
        Usuario usuarioEmpleado = new Usuario();
        Producto codigoProducto = new Producto();
        String correoCliente = correoClienteTxt.getText();
        String correoEmpleado = correoEmpleadoTxt.getText();
        String codigo = codigoProductoTxt.getText();
        usuarioCliente.setCorreo(correoCliente);
        usuarioEmpleado.setCorreo(correoEmpleado);
        codigoProducto.setCodigo(codigo);
        JCalendar j = new JCalendar();
        String fecha = new SimpleDateFormat("yyyy/MM/dd").format(j.getDate());
        asi.agregarServicioImpl(correoCliente, correoEmpleado, codigo, fecha);
        JOptionPane.showMessageDialog(null, "Compra efectuada");
    }
    
    public void limpiarCampos(){
        pagoTxt.setText(null);
        costoTxt.setText(null);
        ingreseNombreClienteTxt.setText(null);
        ingreseNombreEmpleadoTxt.setText(null);
        correoClienteTxt.setText(null);
        correoEmpleadoTxt.setText(null);
        codigoProductoTxt.setText(null);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLocaleChooser1 = new com.toedter.components.JLocaleChooser();
        jPanel1 = new javax.swing.JPanel();
        regresarBtn = new javax.swing.JButton();
        logOutBtn = new javax.swing.JButton();
        label = new javax.swing.JLabel();
        ingreseNombreClienteTxt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        imagenLbl = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        correoClienteTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        ingreseNombreEmpleadoTxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        correoEmpleadoTxt = new javax.swing.JTextField();
        buscarClienteBoton = new javax.swing.JButton();
        mostrarClientesBoton = new javax.swing.JButton();
        buscarEmpleadoBoton = new javax.swing.JButton();
        mostrarEmpleadosBoton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClientes = new javax.swing.JTable();
        codigoProductoTxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        costoTxt = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        pagoTxt = new javax.swing.JTextField();
        veinteTxt = new javax.swing.JButton();
        cincuentaTxt = new javax.swing.JButton();
        cienTxt = new javax.swing.JButton();
        doscientosTxt = new javax.swing.JButton();
        quinientosTxt = new javax.swing.JButton();
        milTxt = new javax.swing.JButton();
        pagarBtn = new javax.swing.JButton();
        borrarCamposBtn = new javax.swing.JButton();
        lblLogo = new javax.swing.JLabel();
        lblFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        regresarBtn.setBackground(new java.awt.Color(0, 0, 51));
        regresarBtn.setForeground(new java.awt.Color(255, 255, 255));
        regresarBtn.setText("Regresar");
        regresarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(regresarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 230, -1, -1));

        logOutBtn.setBackground(new java.awt.Color(0, 0, 51));
        logOutBtn.setForeground(new java.awt.Color(255, 255, 255));
        logOutBtn.setText("Cerrar sesión");
        logOutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutBtnActionPerformed(evt);
            }
        });
        jPanel1.add(logOutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 290, 117, -1));

        label.setForeground(new java.awt.Color(255, 255, 255));
        label.setText("label");
        jPanel1.add(label, new org.netbeans.lib.awtextra.AbsoluteConstraints(1078, 186, -1, -1));

        ingreseNombreClienteTxt.setBackground(new java.awt.Color(0, 0, 51));
        ingreseNombreClienteTxt.setForeground(new java.awt.Color(255, 255, 255));
        ingreseNombreClienteTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingreseNombreClienteTxtActionPerformed(evt);
            }
        });
        jPanel1.add(ingreseNombreClienteTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 45, 161, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nombre cliente:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 19, -1, -1));
        jPanel1.add(imagenLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1078, 58, 100, 100));

        tablaProductos.setBackground(new java.awt.Color(0, 0, 51));
        tablaProductos.setForeground(new java.awt.Color(255, 255, 255));
        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Costo", "Descripcion", "código"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProductosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaProductos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 450, 332, 193));

        tablaEmpleados.setBackground(new java.awt.Color(0, 0, 51));
        tablaEmpleados.setForeground(new java.awt.Color(255, 255, 255));
        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellidos", "Correo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEmpleadosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablaEmpleados);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 450, 380, 193));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre empleado:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 149, -1, -1));

        correoClienteTxt.setEditable(false);
        correoClienteTxt.setBackground(new java.awt.Color(0, 0, 51));
        correoClienteTxt.setForeground(new java.awt.Color(255, 255, 255));
        correoClienteTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoClienteTxtActionPerformed(evt);
            }
        });
        jPanel1.add(correoClienteTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 105, 161, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Correo cliente:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 85, -1, -1));

        ingreseNombreEmpleadoTxt.setBackground(new java.awt.Color(0, 0, 51));
        ingreseNombreEmpleadoTxt.setForeground(new java.awt.Color(255, 255, 255));
        ingreseNombreEmpleadoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingreseNombreEmpleadoTxtActionPerformed(evt);
            }
        });
        jPanel1.add(ingreseNombreEmpleadoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 187, 161, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Correo empleado:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 217, -1, -1));

        correoEmpleadoTxt.setEditable(false);
        correoEmpleadoTxt.setBackground(new java.awt.Color(0, 0, 51));
        correoEmpleadoTxt.setForeground(new java.awt.Color(255, 255, 255));
        correoEmpleadoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoEmpleadoTxtActionPerformed(evt);
            }
        });
        jPanel1.add(correoEmpleadoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 243, 161, -1));

        buscarClienteBoton.setBackground(new java.awt.Color(0, 0, 51));
        buscarClienteBoton.setForeground(new java.awt.Color(255, 255, 255));
        buscarClienteBoton.setText("Buscar cliente");
        buscarClienteBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarClienteBotonActionPerformed(evt);
            }
        });
        jPanel1.add(buscarClienteBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 41, 168, -1));

        mostrarClientesBoton.setBackground(new java.awt.Color(0, 0, 51));
        mostrarClientesBoton.setForeground(new java.awt.Color(255, 255, 255));
        mostrarClientesBoton.setText("Mostrar clientes");
        mostrarClientesBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarClientesBotonActionPerformed(evt);
            }
        });
        jPanel1.add(mostrarClientesBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 101, 168, -1));

        buscarEmpleadoBoton.setBackground(new java.awt.Color(0, 0, 51));
        buscarEmpleadoBoton.setForeground(new java.awt.Color(255, 255, 255));
        buscarEmpleadoBoton.setText("Buscar empleado");
        buscarEmpleadoBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarEmpleadoBotonActionPerformed(evt);
            }
        });
        jPanel1.add(buscarEmpleadoBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 178, 168, -1));

        mostrarEmpleadosBoton.setBackground(new java.awt.Color(0, 0, 51));
        mostrarEmpleadosBoton.setForeground(new java.awt.Color(255, 255, 255));
        mostrarEmpleadosBoton.setText("Mostrar empleados");
        mostrarEmpleadosBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarEmpleadosBotonActionPerformed(evt);
            }
        });
        jPanel1.add(mostrarEmpleadosBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 239, 168, -1));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Código producto:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 277, -1, -1));

        tablaClientes.setBackground(new java.awt.Color(0, 0, 51));
        tablaClientes.setForeground(new java.awt.Color(255, 255, 255));
        tablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellidos", "Correo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaClientes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 380, 193));

        codigoProductoTxt.setEditable(false);
        codigoProductoTxt.setBackground(new java.awt.Color(0, 0, 51));
        codigoProductoTxt.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(codigoProductoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 324, 161, -1));

        jLabel6.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TABLA PRODUCTOS");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 400, -1, -1));

        jLabel7.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("TABLA EMPLEADOS");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 400, -1, -1));

        jLabel8.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Agregar servicio");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(529, 58, -1, -1));

        jLabel9.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("TABLA CLIENTES");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, -1, -1));

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Costo:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 109, -1, -1));

        costoTxt.setBackground(new java.awt.Color(0, 0, 51));
        costoTxt.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(costoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 145, 112, -1));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Paga con:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 199, -1, -1));

        pagoTxt.setBackground(new java.awt.Color(0, 0, 51));
        pagoTxt.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(pagoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 221, 112, -1));

        veinteTxt.setBackground(new java.awt.Color(0, 0, 51));
        veinteTxt.setForeground(new java.awt.Color(255, 255, 255));
        veinteTxt.setText("$20");
        veinteTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                veinteTxtActionPerformed(evt);
            }
        });
        jPanel1.add(veinteTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 266, 58, -1));

        cincuentaTxt.setBackground(new java.awt.Color(0, 0, 51));
        cincuentaTxt.setForeground(new java.awt.Color(255, 255, 255));
        cincuentaTxt.setText("$50");
        cincuentaTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cincuentaTxtActionPerformed(evt);
            }
        });
        jPanel1.add(cincuentaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 266, 57, -1));

        cienTxt.setBackground(new java.awt.Color(0, 0, 51));
        cienTxt.setForeground(new java.awt.Color(255, 255, 255));
        cienTxt.setText("$100");
        cienTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cienTxtActionPerformed(evt);
            }
        });
        jPanel1.add(cienTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 266, 65, -1));

        doscientosTxt.setBackground(new java.awt.Color(0, 0, 51));
        doscientosTxt.setForeground(new java.awt.Color(255, 255, 255));
        doscientosTxt.setText("$200");
        doscientosTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doscientosTxtActionPerformed(evt);
            }
        });
        jPanel1.add(doscientosTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 316, -1, -1));

        quinientosTxt.setBackground(new java.awt.Color(0, 0, 51));
        quinientosTxt.setForeground(new java.awt.Color(255, 255, 255));
        quinientosTxt.setText("$500");
        quinientosTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quinientosTxtActionPerformed(evt);
            }
        });
        jPanel1.add(quinientosTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 316, -1, -1));

        milTxt.setBackground(new java.awt.Color(0, 0, 51));
        milTxt.setForeground(new java.awt.Color(255, 255, 255));
        milTxt.setText("$1000");
        milTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milTxtActionPerformed(evt);
            }
        });
        jPanel1.add(milTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 316, -1, -1));

        pagarBtn.setBackground(new java.awt.Color(0, 0, 51));
        pagarBtn.setForeground(new java.awt.Color(255, 255, 255));
        pagarBtn.setText("Pagar");
        pagarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(pagarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(633, 212, -1, -1));

        borrarCamposBtn.setBackground(new java.awt.Color(0, 0, 51));
        borrarCamposBtn.setForeground(new java.awt.Color(255, 255, 255));
        borrarCamposBtn.setText("Borrar campos");
        borrarCamposBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarCamposBtnActionPerformed(evt);
            }
        });
        jPanel1.add(borrarCamposBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 170, -1, -1));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mx/itson/carWash/capaPresentacion/imagenes/logoTWPeque.png"))); // NOI18N
        jPanel1.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 30, -1, 100));

        lblFondo.setBackground(new java.awt.Color(0, 0, 51));
        lblFondo.setForeground(new java.awt.Color(255, 255, 255));
        lblFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mx/itson/carWash/capaPresentacion/imagenes/FondoPrograma.jpg"))); // NOI18N
        jPanel1.add(lblFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1150, 650));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1151, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logOutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutBtnActionPerformed
        CerrarSesionImpl c = new CerrarSesionImpl();
        int opcion = JOptionPane.showConfirmDialog(null, "¿Cerrar sesion?", "Cerrar sesion", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            if (c.cerrarSesion()) {
                LogIn l = new LogIn();
                JOptionPane.showMessageDialog(null, "Sesion cerrada");
                this.dispose();
                l.setVisible(true);
            }
        }
    }//GEN-LAST:event_logOutBtnActionPerformed

    private void tablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaClientesMouseClicked
        //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = tablaClientes.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) tablaClientes.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        String x = (String) modelotabla.getValueAt(filaSeleccionada, 0);
        String y = (String) modelotabla.getValueAt(filaSeleccionada, 1);
        String z = (String) modelotabla.getValueAt(filaSeleccionada, 2);
//        nombreTxt.setText(x);
//        apellidosTxt.setText(y);
        ingreseNombreClienteTxt.setText(x);
        correoClienteTxt.setText(z);


    }//GEN-LAST:event_tablaClientesMouseClicked

    private void regresarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarBtnActionPerformed
        this.dispose();
        vp.setVisible(true);
    }//GEN-LAST:event_regresarBtnActionPerformed

    private void ingreseNombreClienteTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingreseNombreClienteTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ingreseNombreClienteTxtActionPerformed

    private void tablaProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProductosMouseClicked
        if(correoClienteTxt.getText().equals("") || correoEmpleadoTxt.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Seleccionar cliente y empleado para seleccionar el producto");
        }else{
        //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = tablaProductos.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) tablaProductos.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        String x = (String) modelotabla.getValueAt(filaSeleccionada, 0);
        Double y = (Double) modelotabla.getValueAt(filaSeleccionada, 1);
        String z = (String) modelotabla.getValueAt(filaSeleccionada, 2);
        String a = (String) modelotabla.getValueAt(filaSeleccionada, 3);
//        nombreTxt.setText(x);
        costoTxt.setText(String.valueOf(y));
        codigoProductoTxt.setText(String.valueOf(a));
        pagoTxt.setText(String.valueOf(y));
        }
    }//GEN-LAST:event_tablaProductosMouseClicked

    private void tablaEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEmpleadosMouseClicked
        //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = tablaEmpleados.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) tablaEmpleados.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        String x = (String) modelotabla.getValueAt(filaSeleccionada, 0);
        String y = (String) modelotabla.getValueAt(filaSeleccionada, 1);
        String z = (String) modelotabla.getValueAt(filaSeleccionada, 2);
//        nombreTxt.setText(x);
//        apellidosTxt.setText(y);
        ingreseNombreEmpleadoTxt.setText(x);
        correoEmpleadoTxt.setText(z);


    }//GEN-LAST:event_tablaEmpleadosMouseClicked

    private void correoClienteTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoClienteTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_correoClienteTxtActionPerformed

    private void ingreseNombreEmpleadoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingreseNombreEmpleadoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ingreseNombreEmpleadoTxtActionPerformed

    private void correoEmpleadoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoEmpleadoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_correoEmpleadoTxtActionPerformed

    private void buscarClienteBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarClienteBotonActionPerformed
        String nombre = ingreseNombreClienteTxt.getText();
        rellenarTablaBusquedaCliente(nombre);
    }//GEN-LAST:event_buscarClienteBotonActionPerformed

    private void mostrarClientesBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarClientesBotonActionPerformed
        rellenarTablaCliente();
    }//GEN-LAST:event_mostrarClientesBotonActionPerformed

    private void buscarEmpleadoBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarEmpleadoBotonActionPerformed
        String nombre = ingreseNombreEmpleadoTxt.getText();
        rellenarTablaBusquedaEmpleado(nombre);
    }//GEN-LAST:event_buscarEmpleadoBotonActionPerformed

    private void mostrarEmpleadosBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarEmpleadosBotonActionPerformed
        rellenarTablaEmpleado();
    }//GEN-LAST:event_mostrarEmpleadosBotonActionPerformed

    private void cincuentaTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cincuentaTxtActionPerformed
        pagoTxt.setText("50");
    }//GEN-LAST:event_cincuentaTxtActionPerformed

    private void veinteTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_veinteTxtActionPerformed
        pagoTxt.setText("20");
    }//GEN-LAST:event_veinteTxtActionPerformed

    private void cienTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cienTxtActionPerformed
        pagoTxt.setText("100");
    }//GEN-LAST:event_cienTxtActionPerformed

    private void doscientosTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doscientosTxtActionPerformed
        pagoTxt.setText("200");
    }//GEN-LAST:event_doscientosTxtActionPerformed

    private void quinientosTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quinientosTxtActionPerformed
        pagoTxt.setText("500");
    }//GEN-LAST:event_quinientosTxtActionPerformed

    private void milTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milTxtActionPerformed
        pagoTxt.setText("1000");
    }//GEN-LAST:event_milTxtActionPerformed

    private void pagarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagarBtnActionPerformed
        try {
            double costo = Double.parseDouble(costoTxt.getText());
            double pago = Double.parseDouble(pagoTxt.getText());
            double cambio;
            double aceptable = costo + 1000;
            if(pago<aceptable){
            if (pago >= costo) {
                cambio = pago-costo;
                JOptionPane.showMessageDialog(null, "Su pago fue de: " + pago + "Su cambio es: " + cambio);
                realizarCompra();
                limpiarCampos();
            }
            if(pago < costo){
                JOptionPane.showMessageDialog(null, "Pago insuficiente");
                pagoTxt.setText(String.valueOf(costo));
            }}else{
                JOptionPane.showMessageDialog(null, "Revisar la cantidad introducida");
                pagoTxt.setText(String.valueOf(costo));
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Introducir campos númericos al pagar");
        }
    }//GEN-LAST:event_pagarBtnActionPerformed

    private void borrarCamposBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarCamposBtnActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_borrarCamposBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarServicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton borrarCamposBtn;
    private javax.swing.JButton buscarClienteBoton;
    private javax.swing.JButton buscarEmpleadoBoton;
    private javax.swing.JButton cienTxt;
    private javax.swing.JButton cincuentaTxt;
    private javax.swing.JTextField codigoProductoTxt;
    private javax.swing.JTextField correoClienteTxt;
    private javax.swing.JTextField correoEmpleadoTxt;
    private javax.swing.JTextField costoTxt;
    private javax.swing.JButton doscientosTxt;
    private javax.swing.JLabel imagenLbl;
    private javax.swing.JTextField ingreseNombreClienteTxt;
    private javax.swing.JTextField ingreseNombreEmpleadoTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private com.toedter.components.JLocaleChooser jLocaleChooser1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel label;
    private javax.swing.JLabel lblFondo;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JButton logOutBtn;
    private javax.swing.JButton milTxt;
    private javax.swing.JButton mostrarClientesBoton;
    private javax.swing.JButton mostrarEmpleadosBoton;
    private javax.swing.JButton pagarBtn;
    private javax.swing.JTextField pagoTxt;
    private javax.swing.JButton quinientosTxt;
    private javax.swing.JButton regresarBtn;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTable tablaEmpleados;
    private javax.swing.JTable tablaProductos;
    private javax.swing.JButton veinteTxt;
    // End of variables declaration//GEN-END:variables
}
