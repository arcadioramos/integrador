/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import mx.itson.carWash.capaNegocio.Usuario;

/**
 *
 * @author PAVILION
 */
public class AgregarEmpleadoImpl {
    public boolean agregarEmpleado(Object u){
        Usuario usr = (Usuario) u;
        boolean exito = false;
        try {
            Connection conx = Conexion.getConnection();
            String query = "INSERT INTO usuario(nombre,apellidos,correo,password,tipoUsuario)VALUES(?,?,?,?,?) ";
            PreparedStatement st = conx.prepareStatement(query);
            st.setString(1, usr.getNombre());
            st.setString(2, usr.getApellidos());
            st.setString(3, usr.getCorreo());
            st.setString(4, usr.getPassword());
            st.setInt(5, usr.getTipoUsuario());
            st.execute();
            conx.close();
            exito = true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se ha introducido");
            exito = false;
        }
        return exito;
    }
}
