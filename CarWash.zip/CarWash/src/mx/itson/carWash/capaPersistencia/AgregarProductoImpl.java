/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import mx.itson.carWash.capaNegocio.Producto;

/**
 *
 * @author HP Pavilion
 */
public class AgregarProductoImpl {
    public boolean agregarProducto(Object p){
        Producto pro = (Producto) p;
        boolean exito = false;
        try {
            Connection conx = Conexion.getConnection();
            String query = "INSERT INTO producto(nombre,costo,descripcion)VALUES(?,?,?)";
            PreparedStatement st = conx.prepareStatement(query);
            st.setString(1, pro.getNombre());
            st.setDouble(2, pro.getCosto());
            st.setString(3, pro.getDescripcion());
            st.execute();
            conx.close();
            exito = true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se ha introducido");
            exito = false;
        }
        return exito;
    }
}
