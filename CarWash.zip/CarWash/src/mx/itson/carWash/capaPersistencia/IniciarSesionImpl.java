/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import mx.itson.carWash.capaNegocio.Usuario;

/**
 *
 * @author PAVILION
 */
public class IniciarSesionImpl {
    public boolean LogIn(Object u){
            Usuario usr = (Usuario) u;
            boolean exito = false;
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT id, nombre, apellidos,tipoUsuario FROM usuario WHERE correo = '" + usr.getCorreo() +"' and password = '" + usr.getPassword() + "'";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                exito = true;
                
            }
           
}
catch(SQLException e) {
    //do something to handle the exception, e.g.
    System.out.println("Message: " + e.getMessage());
}
        return exito;
    }
}
