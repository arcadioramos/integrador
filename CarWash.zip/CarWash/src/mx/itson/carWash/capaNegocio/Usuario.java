/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaNegocio;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import mx.itson.carWash.capaPersistencia.AgregarEmpleadoImpl;
import mx.itson.carWash.capaPersistencia.IniciarSesionImpl;

/**
 *
 * @author HP Pavilion
 */
public class Usuario {
    private int id;
    private String nombre;
    private String apellidos;
    private String correo;
    private String password;
    private int tipoUsuario;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the tipoUsuario
     */
    public int getTipoUsuario() {
        return tipoUsuario;
    }

    /**
     * @param tipoUsuario the tipoUsuario to set
     */
    public void setTipoUsuario(int tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
    public void guardarEmpleado(Object u){
        Usuario usuario = (Usuario) u;
        if(usuario.getNombre().equals("") || usuario.getApellidos().equals("") || usuario.getCorreo().equals("") ||
                usuario.getPassword().equals("")){
            JOptionPane.showMessageDialog(null, "No campos vacios");
        }else{
            AgregarEmpleadoImpl a = new AgregarEmpleadoImpl();
            if(a.agregarEmpleado(usuario)){
                JOptionPane.showMessageDialog(null, "Usuario agregado");
            }else{
                JOptionPane.showMessageDialog(null, "Error al agregar");
            }
        }
        
    }
    public Object IniciarSesion(Object u){
        Usuario usuario = (Usuario) u;
        Usuario usr = new Usuario();
        if(usuario.getCorreo().equals("") || usuario.getPassword().equals("")){
            JOptionPane.showMessageDialog(null, "No campos vacios");  
        }else{
         IniciarSesionImpl i = new IniciarSesionImpl();
         usr = (Usuario) i.LogIn(usuario);
         if(usr.getId() != 0){
             JOptionPane.showMessageDialog(null,"Correcto inicio de sesión");
             
         }else{
             System.out.println("error");
         }
            
        }
       return usr;
    }
}
