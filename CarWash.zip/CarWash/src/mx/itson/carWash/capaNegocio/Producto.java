/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaNegocio;

import mx.itson.carWash.capaPersistencia.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import mx.itson.carWash.capaPersistencia.AgregarProductoImpl;

/**
 *
 * @author HP Pavilion
 */
public class Producto {
    private int id;
    private String nombre;
    private double costo;
    private String descripcion;
    private Connection _con;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the costo
     */
    public double getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(double costo) {
        this.costo = costo;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public void guardarProducto(Object p){
        Producto producto = (Producto) p;
        if(producto.getNombre().equals("") || producto.getDescripcion().equals("")){
            JOptionPane.showMessageDialog(null, "No campos vacios");
        }else{
            AgregarProductoImpl a = new AgregarProductoImpl();
            if(a.agregarProducto(producto)){
                JOptionPane.showMessageDialog(null, "Producto agregado");
            }else{
                JOptionPane.showMessageDialog(null, "Error al agregar");
            }
    }   
    }
}

