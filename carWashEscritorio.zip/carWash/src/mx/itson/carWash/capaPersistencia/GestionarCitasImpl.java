/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import mx.itson.carWash.capaNegocio.Cita;

/**
 *
 * @author PAVILION
 */
public class GestionarCitasImpl {

    public boolean aceptarCita(int x) {
        boolean exito = false;

        try {
            Connection conx = Conexion.getConnection();
            String query = "UPDATE cita SET aprobacion =1 WHERE id=" + x;
            PreparedStatement st = conx.prepareStatement(query);
            st.executeUpdate();
            conx.close();
            exito = true;

        } catch (Exception e) {
            System.err.println(e);
        }
        return exito;
    }

    public Object MostrarCitasNoAprobadas() {
        java.util.List<Cita> listaCitasNoAprobadas = new ArrayList();

        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT id,idcliente,fechaCita,aprobacion FROM cita WHERE aprobacion = 0";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getInt(1));
                cita.setIdCliente(rs.getInt(2));
                cita.setFecha(rs.getString(3));
                cita.setAprobacion(rs.getInt(4));
                listaCitasNoAprobadas.add(cita);

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return listaCitasNoAprobadas;

    }

    public Object MostrarCitasAprobadas() {
        java.util.List<Cita> listaCitasAprobadas = new ArrayList();

        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT id,idcliente,fechaCita,aprobacion FROM cita WHERE aprobacion = 1";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getInt(1));
                cita.setIdCliente(rs.getInt(2));
                cita.setFecha(rs.getString(3));
                cita.setAprobacion(rs.getInt(4));
                listaCitasAprobadas.add(cita);

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return listaCitasAprobadas;

    }

    public Object mostrarCitasNoAprobadasPorFecha(String fechaInicio, String fechaFinal) {
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT id,idcliente,fechaCita,aprobacion FROM cita WHERE aprobacion=0 AND fechaCita BETWEEN '"+fechaInicio+"' AND '"+fechaFinal+"' "+ "ORDER BY id";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getInt(1));
                cita.setIdCliente(rs.getInt(2));
                cita.setFecha(rs.getString(3));
                cita.setAprobacion(rs.getInt(4));
                listaCitasFiltradas.add(cita);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return listaCitasFiltradas;

    }
    public Object mostrarCitasAprobadasPorFecha(String fechaInicio, String fechaFinal) {
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT id,idcliente,fechaCita,aprobacion FROM cita WHERE aprobacion=1 AND fechaCita BETWEEN '"+fechaInicio+"' AND '"+fechaFinal+"' "+ "ORDER BY id";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getInt(1));
                cita.setIdCliente(rs.getInt(2));
                cita.setFecha(rs.getString(3));
                cita.setAprobacion(rs.getInt(4));
                listaCitasFiltradas.add(cita);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return listaCitasFiltradas;

    }
}
