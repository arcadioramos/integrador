/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPersistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import mx.itson.carWash.capaNegocio.Producto;
import mx.itson.carWash.capaNegocio.Usuario;
import mx.itson.carWash.capaNegocio.Venta;

/**
 *
 * @author HP Pavilion
 */
public class VentasImpl {

    public Object mostrarTodas() {
        List<Venta> ventas = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT servicio.id, usuario.nombre, u2.nombre, producto.nombre, producto.costo, servicio.fecha "
                    + "FROM servicio "
                    + "INNER JOIN usuario ON servicio.idCliente = usuario.id "
                    + "INNER JOIN usuario AS u2 ON servicio.idEmpleado = u2.id "
                    + "INNER JOIN producto ON servicio.idProducto = producto.id ORDER BY id";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt(1));
                venta.setCliente(rs.getString(2));
                venta.setEmpleado(rs.getString(3));
                venta.setDescripcion(rs.getString(4));
                venta.setCosto(rs.getDouble(5));
                venta.setFecha(rs.getString(6));
                ventas.add(venta);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return ventas;

    }

    public Object mostrarUsuarios(int filtro) {
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        String query = "";
        try {
            Connection conx = Conexion.getConnection();
            if (filtro == 1) {
                query = "SELECT id,nombre,apellidos,correo,tipoUsuario FROM usuario where  tipoUsuario=2";
            }
            if (filtro == 2) {
                query = "SELECT id,nombre,apellidos,correo,tipoUsuario FROM usuario where  tipoUsuario=1";
            }
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt(1));
                usuario.setNombre(rs.getString(2));
                usuario.setApellidos(rs.getString(3));
                usuario.setCorreo(rs.getString(4));
                usuario.setTipoUsuario(rs.getInt(5));

                listaUsuarios.add(usuario);

            }

        } catch (Exception e) {

        }
        return listaUsuarios;

    }

    public Object mostrarFiltro(String correo, int opcion) {
        List<Venta> ventas = new ArrayList();
        String query = "";
        try {
            Connection conx = Conexion.getConnection();
            if (opcion == 2) {
                query = "SELECT servicio.id, usuario.nombre, u2.nombre, producto.nombre, producto.costo, servicio.fecha "
                        + "FROM servicio "
                        + "INNER JOIN usuario ON servicio.idCliente = usuario.id "
                        + "INNER JOIN usuario AS u2 ON servicio.idEmpleado = u2.id "
                        + "INNER JOIN producto ON servicio.idProducto = producto.id "
                        + " WHERE u2.correo = '" + correo
                        + "'ORDER BY id";
            }
            if (opcion == 1) {
                query = "SELECT servicio.id, usuario.nombre, u2.nombre, producto.nombre, producto.costo, servicio.fecha "
                        + "FROM servicio "
                        + "INNER JOIN usuario ON servicio.idCliente = usuario.id "
                        + "INNER JOIN usuario AS u2 ON servicio.idEmpleado = u2.id "
                        + "INNER JOIN producto ON servicio.idProducto = producto.id "
                        + " WHERE usuario.correo = '" + correo
                        + "'ORDER BY id";
            }
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt(1));
                venta.setCliente(rs.getString(2));
                venta.setEmpleado(rs.getString(3));
                venta.setDescripcion(rs.getString(4));
                venta.setCosto(rs.getDouble(5));
                venta.setFecha(rs.getString(6));
                ventas.add(venta);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return ventas;
    }

    public Object mostrarProductos() {
        java.util.List<Producto> listaProductos = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT * FROM producto";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Producto producto = new Producto();
                producto.setId(rs.getInt(1));
                producto.setNombre(rs.getString(2));
                producto.setCosto(rs.getDouble(3));
                producto.setDescripcion(rs.getString(4));
                producto.setCodigo(rs.getString(5));
                listaProductos.add(producto);

            }
        } catch (Exception e) {

        }
        return listaProductos;

    }

    public Object mostrarFiltroProducto(String codigo) {
        List<Venta> ventas = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT servicio.id, usuario.nombre, u2.nombre, producto.nombre, producto.costo, servicio.fecha "
                    + "FROM servicio "
                    + "INNER JOIN usuario ON servicio.idCliente = usuario.id "
                    + "INNER JOIN usuario AS u2 ON servicio.idEmpleado = u2.id "
                    + "INNER JOIN producto ON servicio.idProducto = producto.id "
                    + " WHERE producto.codigo = '" + codigo
                    + "'ORDER BY id";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt(1));
                venta.setCliente(rs.getString(2));
                venta.setEmpleado(rs.getString(3));
                venta.setDescripcion(rs.getString(4));
                venta.setCosto(rs.getDouble(5));
                venta.setFecha(rs.getString(6));
                ventas.add(venta);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return ventas;
    }

    public Object MostrarUsuariosBusqueda(String nombre, int opcion) {
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        String query = "";
        try {
            Connection conx = Conexion.getConnection();
            switch (opcion) {
                case 1:
                    query = "SELECT id,nombre,apellidos,correo,tipoUsuario FROM usuario where  tipoUsuario=1 and nombre LIKE '%" + nombre + "%'";
                    break;
                case 2:
                    query = "SELECT id,nombre,apellidos,correo,tipoUsuario FROM usuario WHERE tipoUsuario=2 AND nombre LIKE '%" + nombre + "%'";
                    break;
            }
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt(1));
                usuario.setNombre(rs.getString(2));
                usuario.setApellidos(rs.getString(3));
                usuario.setCorreo(rs.getString(4));
                usuario.setTipoUsuario(rs.getInt(5));

                listaUsuarios.add(usuario);

            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return listaUsuarios;

    }

    public Object mostrarProductosBusqueda(String nombre) {
        java.util.List<Producto> listaProductos = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT * FROM producto WHERE nombre LIKE '%" + nombre + "%'";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Producto producto = new Producto();
                producto.setId(rs.getInt(1));
                producto.setNombre(rs.getString(2));
                producto.setCosto(rs.getDouble(3));
                producto.setDescripcion(rs.getString(4));
                producto.setCodigo(rs.getString(5));
                listaProductos.add(producto);

            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return listaProductos;

    }
    
    public Object mostrarServiciosPorFecha(String fechaInicio, String fechaFinal) {
        List<Venta> ventas = new ArrayList();
        try {
            Connection conx = Conexion.getConnection();
            String query = "SELECT servicio.id, usuario.nombre, u2.nombre, producto.nombre, producto.costo, servicio.fecha "
                    + "FROM servicio "
                    + "INNER JOIN usuario ON servicio.idCliente = usuario.id "
                    + "INNER JOIN usuario AS u2 ON servicio.idEmpleado = u2.id "
                    + "INNER JOIN producto ON servicio.idProducto = producto.id "
                    + " WHERE servicio.fecha BETWEEN '"+fechaInicio+"' AND '"+fechaFinal+"' "
                    + "ORDER BY id";
            PreparedStatement st = conx.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt(1));
                venta.setCliente(rs.getString(2));
                venta.setEmpleado(rs.getString(3));
                venta.setDescripcion(rs.getString(4));
                venta.setCosto(rs.getDouble(5));
                venta.setFecha(rs.getString(6));
                ventas.add(venta);
            }
        } catch (Exception e) {
            System.out.println(e);

        }
        return ventas;

    }
}
