/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPresentacion;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mx.itson.carWash.capaNegocio.Producto;
import mx.itson.carWash.capaNegocio.Usuario;
import mx.itson.carWash.capaNegocio.Venta;
import mx.itson.carWash.capaPersistencia.AgregarProductoImpl;
import mx.itson.carWash.capaPersistencia.AgregarServicioImpl;
import mx.itson.carWash.capaPersistencia.VentasImpl;

/**
 *
 * @author HP Pavilion
 */
public class Ventas extends javax.swing.JFrame {

    DefaultTableModel modelo;
    DefaultTableModel modelo2;
    DefaultTableModel modelo3;
    int busqueda = 2;

    /**
     * Creates new form Ventas
     */
    public Ventas() {
        initComponents();
        modelo = (DefaultTableModel) tablaVentas.getModel();
        modelo2 = (DefaultTableModel) tablaUsuarios.getModel();
        modelo3 = (DefaultTableModel) tablaProductos.getModel();
        jScrollPane2.setVisible(false);
        tablaUsuarios.removeColumn(tablaUsuarios.getColumnModel().getColumn(3));
        noHayVentasTxt.setVisible(false);
        primeraTablaTxt.setVisible(false);
        rellenarTablaUsuarios(1);
    }

    public void rellenarTablaVentas(String correo, boolean filtro, int opcion) {
        double total = 0;
        VentasImpl vi = new VentasImpl();
        java.util.List<Venta> _listaVentas = new ArrayList();
        modelo.setRowCount(0);
        if (!filtro) {
            _listaVentas = (ArrayList) vi.mostrarTodas();
        } else {
            _listaVentas = (ArrayList) vi.mostrarFiltro(correo, opcion);
        }
        if (_listaVentas.isEmpty()) {
            jScrollPane1.setVisible(false);
            noHayVentasTxt.setText("No ventas registradas con correo: " + correo);
            noHayVentasTxt.setVisible(true);
            totalLbl.setVisible((false));
            totalTextoTxt.setVisible((false));
        } else {
            jScrollPane1.setVisible(true);
            noHayVentasTxt.setVisible(false);
            totalLbl.setVisible((true));
            totalTextoTxt.setVisible((true));
            //Se crea esta condición para que no duplique valores
            //Se crea un for para recorrer el array con los productos
            if (!_listaVentas.isEmpty()) {
                for (int i = 0; i < _listaVentas.size(); i++) {
                    //Se crea un vector para poder añadir filas
                    Vector v = new Vector();
                    //Cada variable representa una columna en la fila del vector
                    int a = _listaVentas.get(i).getId();
                    String b = _listaVentas.get(i).getCliente();
                    String c = _listaVentas.get(i).getEmpleado();
                    String d = _listaVentas.get(i).getDescripcion();
                    double e = _listaVentas.get(i).getCosto();
                    String f = _listaVentas.get(i).getFecha();
                    v.add(b); //Get del nombre
                    v.add(c); //Get de apellidos
                    v.add(d); //Get de correo
                    v.add(e);
                    v.add(f);
                    total += e;
                    //Se añade la fila a la tabla
                    modelo.addRow(v);
                }
            }
            totalLbl.setText(String.valueOf(total));
        }
    }

    public void rellenarTablaUsuarios(int filtro) {
        VentasImpl vi = new VentasImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) vi.mostrarUsuarios(filtro);
        //Se crea esta condición para que no duplique valores
        modelo2.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        if (listaUsuarios.isEmpty()) {
            jScrollPane2.setVisible(false);
            jScrollPane3.setVisible(false);
            primeraTablaTxt.setText("No hay usuarios registrados en esta sección");
            primeraTablaTxt.setVisible(true);
        } else {
            jScrollPane3.setVisible(true);
            primeraTablaTxt.setVisible(false);
            for (int i = 0; i < listaUsuarios.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaUsuarios.get(i).getId();
                String b = listaUsuarios.get(i).getNombre();
                String c = listaUsuarios.get(i).getApellidos();
                String d = listaUsuarios.get(i).getCorreo();
                int e = listaUsuarios.get(i).getTipoUsuario();
                //v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                v.add(e);
                // v.add(e);
                //Se añade la fila a la tabla
                modelo2.addRow(v);
            }
        }

    }

    public void rellenarTablaUsuariosBusqueda(String nombre, int opcion) {
        VentasImpl vi = new VentasImpl();
        java.util.List<Usuario> listaUsuarios = new ArrayList();
        listaUsuarios = (ArrayList) vi.MostrarUsuariosBusqueda(nombre, opcion);
        //Se crea esta condición para que no duplique valores
        modelo2.setRowCount(0);
        //Se crea un for para recorrer el array con los productos
        if (listaUsuarios.isEmpty()) {
            jScrollPane2.setVisible(false);
            jScrollPane3.setVisible(false);
            primeraTablaTxt.setText("No hay usuarios que coincidan");
            primeraTablaTxt.setVisible(true);
        } else {
            jScrollPane3.setVisible(true);
            primeraTablaTxt.setVisible(false);
            for (int i = 0; i < listaUsuarios.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaUsuarios.get(i).getId();
                String b = listaUsuarios.get(i).getNombre();
                String c = listaUsuarios.get(i).getApellidos();
                String d = listaUsuarios.get(i).getCorreo();
                int e = listaUsuarios.get(i).getTipoUsuario();
                //v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                v.add(e);
                // v.add(e);
                //Se añade la fila a la tabla
                modelo2.addRow(v);
            }
        }

    }

    public void rellenarTablaProductos() {
        VentasImpl vi = new VentasImpl();
        java.util.List<Producto> listaProductos = new ArrayList();
        listaProductos = (ArrayList) vi.mostrarProductos();
        //Se crea esta condición para que no duplique valores
        modelo3.setRowCount(0);

        //Se crea un for para recorrer el array con los productos
        if (listaProductos.isEmpty()) {
            jScrollPane2.setVisible(false);
            jScrollPane3.setVisible(false);
            primeraTablaTxt.setText("No hay productos registrados");
            primeraTablaTxt.setVisible(true);
        } else {
            jScrollPane2.setVisible(true);
            primeraTablaTxt.setVisible(false);
            for (int i = 0; i < listaProductos.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                String x = listaProductos.get(i).getNombre();
                double y = listaProductos.get(i).getCosto();
                String z = listaProductos.get(i).getDescripcion();
                String a = listaProductos.get(i).getCodigo();
                int b = listaProductos.get(i).getId();
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //  v.add(b);
                //Se añade la fila a la tabla
                modelo3.addRow(v);
            }
        }

    }

    public void rellenarTablaVentasProducto(String codigo) {
        double total = 0;
        VentasImpl vi = new VentasImpl();
        java.util.List<Venta> _listaVentas = new ArrayList();
        modelo.setRowCount(0);
        {
            _listaVentas = (ArrayList) vi.mostrarFiltroProducto(codigo);
            if (_listaVentas.isEmpty()) {
                jScrollPane1.setVisible(false);
                noHayVentasTxt.setText("No hay ventas registradas del producto con codigo: " + codigo);
                noHayVentasTxt.setVisible(true);
                totalLbl.setVisible((false));
                totalTextoTxt.setVisible((false));
            } else {
                jScrollPane1.setVisible(true);
                noHayVentasTxt.setVisible(false);
                totalLbl.setVisible((true));
                totalTextoTxt.setVisible((true));
                //Se crea esta condición para que no duplique valores
                //Se crea un for para recorrer el array con los productos
                if (!_listaVentas.isEmpty()) {
                    for (int i = 0; i < _listaVentas.size(); i++) {
                        //Se crea un vector para poder añadir filas
                        Vector v = new Vector();
                        //Cada variable representa una columna en la fila del vector
                        int a = _listaVentas.get(i).getId();
                        String b = _listaVentas.get(i).getCliente();
                        String c = _listaVentas.get(i).getEmpleado();
                        String d = _listaVentas.get(i).getDescripcion();
                        double e = _listaVentas.get(i).getCosto();
                        String f = _listaVentas.get(i).getFecha();
                        v.add(b); //Get del nombre
                        v.add(c); //Get de apellidos
                        v.add(d); //Get de correo
                        v.add(e);
                        v.add(f);
                        total += e;
                        //Se añade la fila a la tabla
                        modelo.addRow(v);
                    }
                } else {
                    jScrollPane3.setVisible(false);
                    noHayVentasTxt.setVisible(true);
                }
                totalLbl.setText(String.valueOf(total));
            }

        }
    }

    public void rellenarTablaProductosBusqueda(String nombre) {
        VentasImpl vi = new VentasImpl();
        java.util.List<Producto> listaProductos = new ArrayList();
        listaProductos = (ArrayList) vi.mostrarProductosBusqueda(nombre);
        //Se crea esta condición para que no duplique valores
        modelo3.setRowCount(0);
        if (listaProductos.isEmpty()) {
            jScrollPane2.setVisible(false);
            jScrollPane3.setVisible(false);
            primeraTablaTxt.setText("No hay productos que coincidan con la busqueda");
            primeraTablaTxt.setVisible(true);
        } else {
            jScrollPane2.setVisible(true);
            primeraTablaTxt.setVisible(false);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaProductos.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                String x = listaProductos.get(i).getNombre();
                double y = listaProductos.get(i).getCosto();
                String z = listaProductos.get(i).getDescripcion();
                String a = listaProductos.get(i).getCodigo();
                int b = listaProductos.get(i).getId();
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //  v.add(b);
                //Se añade la fila a la tabla
                modelo3.addRow(v);

            }
        }
        }

    

    public void rellenarTablaVentasPorFecha(String fechaInicial, String fechaFinal) {
        double total = 0;
        VentasImpl vi = new VentasImpl();
        java.util.List<Venta> _listaVentas = new ArrayList();
        modelo.setRowCount(0);
        _listaVentas = (ArrayList) vi.mostrarServiciosPorFecha(fechaInicial, fechaFinal);
        //Se crea esta condición para que no duplique valores
        //Se crea un for para recorrer el array con los productos
        if (_listaVentas.isEmpty()) {
            jScrollPane1.setVisible(false);
            noHayVentasTxt.setText("No hay ventas registradas del: " + fechaInicial + " al: " + fechaFinal);
            noHayVentasTxt.setVisible(true);
            totalLbl.setVisible((false));
            totalTextoTxt.setVisible((false));
        } else {
            jScrollPane1.setVisible(true);
            noHayVentasTxt.setVisible(false);
            totalLbl.setVisible((true));
            totalTextoTxt.setVisible((true));
            for (int i = 0; i < _listaVentas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = _listaVentas.get(i).getId();
                String b = _listaVentas.get(i).getCliente();
                String c = _listaVentas.get(i).getEmpleado();
                String d = _listaVentas.get(i).getDescripcion();
                double e = _listaVentas.get(i).getCosto();
                String f = _listaVentas.get(i).getFecha();
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                v.add(e);
                v.add(f);
                total += e;
                //Se añade la fila a la tabla
                modelo.addRow(v);
            }
        }
        totalLbl.setText(String.valueOf(total));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVentas = new javax.swing.JTable();
        ventasBtn = new javax.swing.JButton();
        regresarBtn = new javax.swing.JButton();
        totalTextoTxt = new javax.swing.JLabel();
        totalLbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        filtrarCombo = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        buscarTxt = new javax.swing.JTextField();
        buscarBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        fechaInicio = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        fechaFin = new com.toedter.calendar.JDateChooser();
        noHayVentasTxt = new javax.swing.JLabel();
        primeraTablaTxt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cliente", "Empleado", "Descripcion", "Total", "Fecha"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaVentas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 90, 550, 227));

        ventasBtn.setText("Mostrar todas las ventas");
        ventasBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventasBtnActionPerformed(evt);
            }
        });
        jPanel1.add(ventasBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, -1, -1));

        regresarBtn.setText("Regresar");
        regresarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(regresarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 490, -1, -1));

        totalTextoTxt.setText("Total:");
        jPanel1.add(totalTextoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(613, 333, -1, -1));
        jPanel1.add(totalLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 114, 14));

        jLabel2.setText("Filtrar por:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellidos", "Correo", "Tipo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuariosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablaUsuarios);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 390, 210));

        filtrarCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Empleado", "Cliente", "Producto" }));
        filtrarCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtrarComboActionPerformed(evt);
            }
        });
        jPanel1.add(filtrarCombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 48, -1, -1));

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Costo", "Descripcion", "Código"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProductosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaProductos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 390, 210));
        jPanel1.add(buscarTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 110, -1));

        buscarBtn.setText("Buscar");
        buscarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(buscarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, -1));

        jLabel3.setText("Filtrar por fecha:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, -1));
        jPanel1.add(fechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 50, 140, -1));

        jButton1.setText("Mostrar ventas por fecha");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, -1, -1));
        jPanel1.add(fechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 140, -1));

        noHayVentasTxt.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jPanel1.add(noHayVentasTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, 590, 140));

        primeraTablaTxt.setFont(new java.awt.Font("Arial", 2, 18)); // NOI18N
        jPanel1.add(primeraTablaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 450, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 40, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ventasBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventasBtnActionPerformed
        rellenarTablaVentas("", false, 3);
    }//GEN-LAST:event_ventasBtnActionPerformed

    private void regresarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarBtnActionPerformed
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);
        dispose();
    }//GEN-LAST:event_regresarBtnActionPerformed

    private void tablaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuariosMouseClicked
        //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) tablaUsuarios.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        String x = (String) modelotabla.getValueAt(filaSeleccionada, 0);
        String y = (String) modelotabla.getValueAt(filaSeleccionada, 1);
        String z = (String) modelotabla.getValueAt(filaSeleccionada, 2);
        int o = (Integer) modelotabla.getValueAt(filaSeleccionada, 3);
        VentasImpl vi = new VentasImpl();
        rellenarTablaVentas(z, true, o);

    }//GEN-LAST:event_tablaUsuariosMouseClicked

    private void filtrarComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtrarComboActionPerformed
        int opcion = filtrarCombo.getSelectedIndex();
        switch (opcion) {
            case 0:
                jScrollPane2.setVisible(false);
                jScrollPane3.setVisible(true);
                rellenarTablaUsuarios(1);
                busqueda = 2;
                break;
            case 1:
                jScrollPane2.setVisible(false);
                jScrollPane3.setVisible(true);
                rellenarTablaUsuarios(2);
                busqueda = 1;
                break;
            case 2:
                jScrollPane3.setVisible(false);
                jScrollPane2.setVisible(true);
                rellenarTablaProductos();
                busqueda = 3;
                break;
        }
    }//GEN-LAST:event_filtrarComboActionPerformed

    private void tablaProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProductosMouseClicked
//        //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = tablaProductos.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) tablaProductos.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        String x = (String) modelotabla.getValueAt(filaSeleccionada, 0);
        Double y = (Double) modelotabla.getValueAt(filaSeleccionada, 1);
        String z = (String) modelotabla.getValueAt(filaSeleccionada, 2);
        String a = (String) modelotabla.getValueAt(filaSeleccionada, 3);
        rellenarTablaVentasProducto(a);
    }//GEN-LAST:event_tablaProductosMouseClicked

    private void buscarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarBtnActionPerformed
        String nombre = buscarTxt.getText();
        if (busqueda < 3) {
            rellenarTablaUsuariosBusqueda(nombre, busqueda);
        } else {
            rellenarTablaProductosBusqueda(nombre);
        }
    }//GEN-LAST:event_buscarBtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            Date fecha1 = fechaInicio.getDate();
            DateFormat f1 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaInicial = f1.format(fecha1);

            Date fecha2 = fechaFin.getDate();
            DateFormat f2 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaFinal = f2.format(fecha2);

            rellenarTablaVentasPorFecha(fechaInicial, fechaFinal);
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Ingresar datos en fechas");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buscarBtn;
    private javax.swing.JTextField buscarTxt;
    private com.toedter.calendar.JDateChooser fechaFin;
    private com.toedter.calendar.JDateChooser fechaInicio;
    private javax.swing.JComboBox<String> filtrarCombo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel noHayVentasTxt;
    private javax.swing.JLabel primeraTablaTxt;
    private javax.swing.JButton regresarBtn;
    private javax.swing.JTable tablaProductos;
    private javax.swing.JTable tablaUsuarios;
    private javax.swing.JTable tablaVentas;
    private javax.swing.JLabel totalLbl;
    private javax.swing.JLabel totalTextoTxt;
    private javax.swing.JButton ventasBtn;
    // End of variables declaration//GEN-END:variables
}
