/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itson.carWash.capaPresentacion;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mx.itson.carWash.capaNegocio.Cita;
import mx.itson.carWash.capaPersistencia.GestionarCitasImpl;

/**
 *
 * @author PAVILION
 */
public class GestionCitas extends javax.swing.JFrame {

    DefaultTableModel modelo;
    DefaultTableModel modelo2;
    static int x;
    static GestionarCitasImpl ec = new GestionarCitasImpl();
   
    /**
     * Creates new form GestionCitas
     */
    public GestionCitas() {
        initComponents();
        
        modelo = (DefaultTableModel) TablaCitasNoAprobadas.getModel();
        modelo2 = (DefaultTableModel) TablaCitasAprobadas.getModel();
        rellenarTablaNoAprobado();
        rellenarTablaAprobado();
    }
        
    public void rellenarTablaNoAprobado() {   
        
        java.util.List<Cita> listaCitas = new ArrayList();
        listaCitas = (ArrayList) ec.MostrarCitasNoAprobadas();
        //Se crea esta condición para que no duplique valores
         modelo.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int x = listaCitas.get(i).getId();
                int y = listaCitas.get(i).getIdCliente();
                String z = listaCitas.get(i).getFecha();
                int a = listaCitas.get(i).getAprobacion();  
                
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //Se añade la fila a la tabla
                modelo.addRow(v);

            }
        
        
    }
    public void rellenarTablaAprobado() {   
        
        java.util.List<Cita> listaCitasAprobadas = new ArrayList();
        listaCitasAprobadas = (ArrayList) ec.MostrarCitasAprobadas();
        //Se crea esta condición para que no duplique valores
         modelo2.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasAprobadas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int x = listaCitasAprobadas.get(i).getId();
                int y = listaCitasAprobadas.get(i).getIdCliente();
                String z = listaCitasAprobadas.get(i).getFecha();
                int a = listaCitasAprobadas.get(i).getAprobacion();  
                
                v.add(x);
                v.add(y);
                v.add(z);
                v.add(a);
                //Se añade la fila a la tabla
                modelo2.addRow(v);

            }
        
        
    }
    public void rellenarTablaCitaNoAprobadaPorFecha(String fechaInicial, String fechaFinal) {
        GestionarCitasImpl gc = new GestionarCitasImpl();
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        
        listaCitasFiltradas = (ArrayList) gc.mostrarCitasNoAprobadasPorFecha(fechaInicial, fechaFinal);
            //Se crea esta condición para que no duplique valores
            modelo.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasFiltradas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaCitasFiltradas.get(i).getId();
                int b = listaCitasFiltradas.get(i).getIdCliente();
                String c = listaCitasFiltradas.get(i).getFecha();
                int d = listaCitasFiltradas.get(i).getAprobacion();
                v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                
                //Se añade la fila a la tabla
                modelo.addRow(v);
            
            
        }
            

    }
    public void rellenarTablaCitaAprobadaPorFecha(String fechaInicial, String fechaFinal) {
        GestionarCitasImpl gc = new GestionarCitasImpl();
        java.util.List<Cita> listaCitasFiltradas = new ArrayList();
        
        listaCitasFiltradas = (ArrayList) gc.mostrarCitasAprobadasPorFecha(fechaInicial, fechaFinal);
            //Se crea esta condición para que no duplique valores
            modelo2.setRowCount(0);
            //Se crea un for para recorrer el array con los productos
            for (int i = 0; i < listaCitasFiltradas.size(); i++) {
                //Se crea un vector para poder añadir filas
                Vector v = new Vector();
                //Cada variable representa una columna en la fila del vector
                int a = listaCitasFiltradas.get(i).getId();
                int b = listaCitasFiltradas.get(i).getIdCliente();
                String c = listaCitasFiltradas.get(i).getFecha();
                int d = listaCitasFiltradas.get(i).getAprobacion();
                v.add(a);
                v.add(b); //Get del nombre
                v.add(c); //Get de apellidos
                v.add(d); //Get de correo
                
                //Se añade la fila a la tabla
                modelo2.addRow(v);
            
            
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCitasAprobadas = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TablaCitasNoAprobadas = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        botonAceptarCita = new javax.swing.JButton();
        fechaInicio = new com.toedter.calendar.JDateChooser();
        fechaFin = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(74, 189, 172));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("GESTOR DE CITAS");

        TablaCitasAprobadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id", "idCliente", "Fecha cita", "Aprobación"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.Long.class, java.lang.String.class, java.lang.Byte.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaCitasAprobadas);

        jLabel2.setText("No aprobadas");

        TablaCitasNoAprobadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id", "idCliente", "Fecha cita", "Aprobación"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.Long.class, java.lang.String.class, java.lang.Byte.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaCitasNoAprobadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaCitasNoAprobadasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TablaCitasNoAprobadas);

        jLabel3.setText("Aprobadas");

        botonAceptarCita.setFont(new java.awt.Font("Tw Cen MT", 1, 14)); // NOI18N
        botonAceptarCita.setText("Aceptar cita");
        botonAceptarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCitaActionPerformed(evt);
            }
        });

        jButton1.setText("Filtrar Fecha");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setText("Fecha inicio");

        jLabel5.setText("Fecha fin");

        jButton2.setText("Regresar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(417, 417, 417)
                                .addComponent(jLabel2)))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addComponent(botonAceptarCita)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(482, 482, 482)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fechaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(fechaFin, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(269, 269, 269)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(34, 34, 34))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(485, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(1, 1, 1)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fechaFin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fechaInicio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(botonAceptarCita))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(274, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(74, 74, 74)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonAceptarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCitaActionPerformed

        ec.aceptarCita(x);
        rellenarTablaNoAprobado();
        rellenarTablaAprobado();
    }//GEN-LAST:event_botonAceptarCitaActionPerformed

    private void TablaCitasNoAprobadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaCitasNoAprobadasMouseClicked
       //Se crea variable para obtener el renglón/fila de la tabla que estamos seleccionando
        int filaSeleccionada = TablaCitasNoAprobadas.getSelectedRow();
        //Se genera el modelo de la tabla
        DefaultTableModel modelotabla = (DefaultTableModel) TablaCitasNoAprobadas.getModel();
        //Se crea una variable para guardar el valor obtenido en la fila seleccionada en su columna tal
        x =(Integer) modelotabla.getValueAt(filaSeleccionada, 0);
        
        
        
        
    }//GEN-LAST:event_TablaCitasNoAprobadasMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try {
            Date fecha1 = fechaInicio.getDate();
            DateFormat f1 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaInicial = f1.format(fecha1);

            Date fecha2 = fechaFin.getDate();
            DateFormat f2 = new SimpleDateFormat("yyyy-MM-dd");
            String fechaFinal = f2.format(fecha2);

            rellenarTablaCitaNoAprobadaPorFecha(fechaInicial, fechaFinal);
            rellenarTablaCitaAprobadaPorFecha(fechaInicial, fechaFinal);
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Ingresar datos en fechas");
        }    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionCitas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaCitasAprobadas;
    private javax.swing.JTable TablaCitasNoAprobadas;
    private javax.swing.JButton botonAceptarCita;
    private com.toedter.calendar.JDateChooser fechaFin;
    private com.toedter.calendar.JDateChooser fechaInicio;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
